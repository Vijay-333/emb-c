#ifndef INC_STM32F4XX_H_
#define INC_STM32F4XX_H_

#include <stdint.h>
#include <stddef.h>

//base address of memory components
#define FLASH_BASE_ADDR 	0x08000000U
#define SRAM_BASE_ADDR 		0x20000000U
#define SRAM1_BASE_ADDR 	SRAM_BASE_ADDR
#define SRAM2_BASE_ADDR 	0x2001C000U
#define ROM_BASE_ADDR 		0x1FFF0000U

//base address of BUS system
#define APB1_BASE_ADDR 		0x40000000U
#define APB2_BASE_ADDR 		0x40010000U
#define AHB1_BASE_ADDR 		0x40020000U

#define NVIC_BASE_ADDR		((volatile uint32_t*) 0xE000E000U)
#define NVIC_ISER0			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x100 ))
#define NVIC_ISER1			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x104 ))
#define NVIC_ISER2			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x108 ))

#define NVIC_ICER0			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x180 ))
#define NVIC_ICER1			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x184 ))
#define NVIC_ICER2			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x188 ))

#define NVIC_IPR0			((volatile uint32_t*) ((NVIC_BASE_ADDR) + 0x400 ))

#define NO_PR_BITS_IMPLEMENTED	4

//base address of peripherals hanging on to APB1 BUS
#define TIM2_BASE_ADDR 					((APB1_BASE_ADDR) + 0x0000U)
#define TIM3_BASE_ADDR 					((APB1_BASE_ADDR) + 0x0400U)
#define TIM4_BASE_ADDR 					((APB1_BASE_ADDR) + 0x0800U)
#define TIM5_BASE_ADDR 					((APB1_BASE_ADDR) + 0x0C00U)
#define TIM6_BASE_ADDR 					((APB1_BASE_ADDR) + 0x1000U)
#define TIM7_BASE_ADDR 					((APB1_BASE_ADDR) + 0x1400U)

#define TIM12_BASE_ADDR 				((APB1_BASE_ADDR) + 0x1800U)
#define TIM13_BASE_ADDR 				((APB1_BASE_ADDR) + 0x1C00U)
#define TIM14_BASE_ADDR 				((APB1_BASE_ADDR) + 0x2000U)

#define RTC_BKP_REG_BASE_ADDR 			((APB1_BASE_ADDR) + 0x2800U)

#define WWDG_BASE_ADDR 					((APB1_BASE_ADDR) + 0x2C00U)
#define IWDG_BASE_ADDR 					((APB1_BASE_ADDR) + 0x3000U)

#define I2S2EXT_BASE_ADDR 				((APB1_BASE_ADDR) + 0x3400U)

#define SPI2_BASE_ADDR 					((APB1_BASE_ADDR) + 0x3800U)
#define SPI3_BASE_ADDR 					((APB1_BASE_ADDR) + 0x3C00U)

#define I2S3EXT_BASE_ADDR 				((APB1_BASE_ADDR) + 0x4000U)

#define USART2_BASE_ADDR 				((APB1_BASE_ADDR) + 0x4400U)
#define USART3_BASE_ADDR 				((APB1_BASE_ADDR) + 0x4800U)

#define UART4_BASE_ADDR 				((APB1_BASE_ADDR) + 0x4C00U)
#define UART5_BASE_ADDR 				((APB1_BASE_ADDR) + 0x5000U)

#define I2C1_BASE_ADDR 					((APB1_BASE_ADDR) + 0x5400U)
#define I2C2_BASE_ADDR 					((APB1_BASE_ADDR) + 0x5800U)
#define I2C3_BASE_ADDR 					((APB1_BASE_ADDR) + 0x5C00U)

#define CAN1_BASE_ADDR 					((APB1_BASE_ADDR) + 0x6400U)
#define CAN2_BASE_ADDR 					((APB1_BASE_ADDR) + 0x6800U)

#define PWR_BASE_ADDR 					((APB1_BASE_ADDR) + 0x7000U)

#define DAC_BASE_ADDR 					((APB1_BASE_ADDR) + 0x7400U)

#define UART7_BASE_ADDR 				((APB1_BASE_ADDR) + 0x7800U)
#define UART8_BASE_ADDR 				((APB1_BASE_ADDR) + 0x7C00U)


//base address of peripherals hanging on to APB2 BUS
#define TIM1_BASE_ADDR 					((APB2_BASE_ADDR) + 0x0000U)
#define TIM8_BASE_ADDR 					((APB2_BASE_ADDR) + 0x0400U)

#define USART1_BASE_ADDR 				((APB2_BASE_ADDR) + 0x1000U)
#define USART6_BASE_ADDR 				((APB2_BASE_ADDR) + 0x1400U)

#define ADC1_ADC2_ADC3_BASE_ADDR 		((APB2_BASE_ADDR) + 0x2000U)

#define SDIO_BASE_ADDR					((APB2_BASE_ADDR) + 0x2C00U)

#define SPI1_BASE_ADDR 					((APB2_BASE_ADDR) + 0x3000U)
#define SPI4_BASE_ADDR 					((APB2_BASE_ADDR) + 0x3400U)

#define SYSCFG_BASE_ADDR 				((APB2_BASE_ADDR) + 0x3800U)

#define EXTI_BASE_ADDR 					((APB2_BASE_ADDR) + 0x3C00U)

#define TIM9_BASE_ADDR 					((APB2_BASE_ADDR) + 0x4000U)
#define TIM10_BASE_ADDR 				((APB2_BASE_ADDR) + 0x4400U)
#define TIM11_BASE_ADDR 				((APB2_BASE_ADDR) + 0x4800U)

#define SPI5_BASE_ADDR 					((APB2_BASE_ADDR) + 0x5000U)
#define SPI6_BASE_ADDR 					((APB2_BASE_ADDR) + 0x5400U)

#define SAI1_BASE_ADDR	 				((APB2_BASE_ADDR) + 0x5800U)

#define LCD_TFT_BASE_ADDR 				((APB2_BASE_ADDR) + 0x6800U)


//base address of peripherals hanging on to AHB1 BUS
#define GPIOA_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x0000U)
#define GPIOB_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x0400U)
#define GPIOC_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x0800U)
#define GPIOD_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x0C00U)
#define GPIOE_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x1000U)
#define GPIOF_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x1400U)
#define GPIOG_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x1800U)
#define GPIOH_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x1C00U)
#define GPIOI_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x2000U)

#define CRC_BASE_ADDR 					((AHB1_BASE_ADDR) + 0x3000U)
#define RCC_BASE_ADDR 					((AHB1_BASE_ADDR) + 0x3800U)

#define FLASH_INTERFACE_REG_BASE_ADDR 	((AHB1_BASE_ADDR) + 0x3C00U)

#define BKPSRAM_BASE_ADDR 				((AHB1_BASE_ADDR) + 0x4000U)

#define DMA1_BASE_ADDR 					((AHB1_BASE_ADDR) + 0x6000U)
#define DMA2_BASE_ADDR 					((AHB1_BASE_ADDR) + 0x6400U)

#define ETHERNET_MAC_BASE_ADDR 			((AHB1_BASE_ADDR) + 0x8000U)

#define DMA2D_BASE_ADDR 				((AHB1_BASE_ADDR) + 0xB000U)

#define USB_OTG_HS_BASE_ADDR 			((AHB1_BASE_ADDR) + 0x20000U)


typedef struct{
	volatile uint32_t MODER;
	volatile uint32_t OTYPER;
	volatile uint32_t OSPEEDR;
	volatile uint32_t PUPDR;
	volatile uint32_t IDR;
	volatile uint32_t ODR;
	volatile uint32_t BSRR;
	volatile uint32_t LCKR;
	volatile uint32_t AFR[2];
}GPIO_RegDef_t;

typedef struct{
	volatile uint32_t RTC_TR;
	volatile uint32_t RTC_DR;
	volatile uint32_t RTC_CR;
	volatile uint32_t RTC_ISR;
	volatile uint32_t RTC_PRER;
	volatile uint32_t RTC_WUTR;
	volatile uint32_t RTC_CALIBR;
	volatile uint32_t RTC_ALRMAR;
	volatile uint32_t RTC_ALRMBR;
	volatile uint32_t RTC_WPR;
	volatile uint32_t RTC_SSR;
	volatile uint32_t RTC_SHIFTR;
	volatile uint32_t RTC_TSTR;
	volatile uint32_t RTC_TSDR;
	volatile uint32_t RTC_TSSSR;
	volatile uint32_t RTC_CALR;
	volatile uint32_t RTC_TAFCR;
	volatile uint32_t RTC_ALRMASSR;
	volatile uint32_t RTC_ALRMBSSR;
	volatile uint32_t RTC_BKPxR;
}RTC_RegDef_t;

typedef struct{
	volatile uint32_t RCC_CR;
	volatile uint32_t RCC_PLLCFGR;
	volatile uint32_t RCC_CFGR;
	volatile uint32_t RCC_CIR;
	volatile uint32_t RCC_AHB1RSTR;
	volatile uint32_t RCC_AHB2RSTR;
	volatile uint32_t RCC_AHB3RSTR;
	uint32_t RESERVED1;
	volatile uint32_t RCC_APB1RSTR;
	volatile uint32_t RCC_APB2RSTR;
	uint32_t RESERVED2[2];
	volatile uint32_t RCC_AHB1ENR;
	volatile uint32_t RCC_AHB2ENR;
	volatile uint32_t RCC_AHB3ENR;
	uint32_t RESERVED3;
	volatile uint32_t RCC_APB1ENR;
	volatile uint32_t RCC_APB2ENR;
	uint32_t RESERVED4[2];
	volatile uint32_t RCC_AHB1LPENR;
	volatile uint32_t RCC_AHB2LPENR;
	volatile uint32_t RCC_AHB3LPENR;
	uint32_t RESERVED5;
	volatile uint32_t RCC_APB1LPENR;
	volatile uint32_t RCC_APB2LPENR;
	uint32_t RESERVED6[2];
	volatile uint32_t RCC_BDCR;
	volatile uint32_t RCC_CSR;
	uint32_t RESERVED7[2];
	volatile uint32_t RCC_SSCGR;
	volatile uint32_t RCC_PLLI2SCFGR;
}RCC_RegDef_t;

typedef struct{
	volatile uint32_t SYSCFG_MEMRMP;
	volatile uint32_t SYSCFG_PMC;
	volatile uint32_t SYSCFG_EXTICR[4];
	uint32_t RESERVED[2];
	volatile uint32_t SYSCFG_CMPCR;
}SYSCFG_RegDef_t;

typedef struct{
	volatile uint32_t EXTI_IMR;
	volatile uint32_t EXTI_EMR;
	volatile uint32_t EXTI_RTSR;
	volatile uint32_t EXTI_FTSR;
	volatile uint32_t EXTI_SWIER;
	volatile uint32_t EXTI_PR;
}EXTI_RegDef_t;

typedef struct {
	volatile uint32_t TIM_CR1;
	volatile uint32_t TIM_CR2;
	volatile uint32_t TIM_SMCR;
	volatile uint32_t TIM_DIER;
	volatile uint32_t TIM_SR;
	volatile uint32_t TIM_EGR;
	volatile uint32_t TIM_CCMR1;
	volatile uint32_t TIM_CCMR2;
	volatile uint32_t TIM_CCER;
	volatile uint32_t TIM_CNT;
	volatile uint32_t TIM_PSC;
	volatile uint32_t TIM_ARR;
	uint32_t RESERVED1;
	volatile uint32_t TIM_CCR1;
	volatile uint32_t TIM_CCR2;
	volatile uint32_t TIM_CCR3;
	volatile uint32_t TIM_CCR4;
	uint32_t RESERVED2;
	volatile uint32_t TIM_DCR;
	volatile uint32_t TIM_DMAR;
	volatile uint32_t TIM_OR;
}TIM_RegDef_t;

#define TIM2				((TIM_RegDef_t*)TIM2_BASE_ADDR)
#define TIM5				((TIM_RegDef_t*)TIM5_BASE_ADDR)

#define GPIOA				((GPIO_RegDef_t*)GPIOA_BASE_ADDR)
#define GPIOB				((GPIO_RegDef_t*)GPIOB_BASE_ADDR)
#define GPIOC				((GPIO_RegDef_t*)GPIOC_BASE_ADDR)
#define GPIOD				((GPIO_RegDef_t*)GPIOD_BASE_ADDR)
#define GPIOE				((GPIO_RegDef_t*)GPIOE_BASE_ADDR)
#define GPIOF				((GPIO_RegDef_t*)GPIOF_BASE_ADDR)
#define GPIOG				((GPIO_RegDef_t*)GPIOG_BASE_ADDR)
#define GPIOH				((GPIO_RegDef_t*)GPIOH_BASE_ADDR)
#define GPIOI				((GPIO_RegDef_t*)GPIOI_BASE_ADDR)

#define RTC					((RTC_RegDef_t*)RTC_BKP_REG_BASE_ADDR)

#define RCC					((RCC_RegDef_t*)RCC_BASE_ADDR)

#define SYSCFG				((SYSCFG_RegDef_t*)SYSCFG_BASE_ADDR)

#define EXTI 				((EXTI_RegDef_t*)EXTI_BASE_ADDR)

//Clock Enable MACROS for GPIOx peripherals
#define GPIOA_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 0))
#define GPIOB_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 1))
#define GPIOC_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 2))
#define GPIOD_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 3))
#define GPIOE_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 4))
#define GPIOF_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 5))
#define GPIOG_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 6))
#define GPIOH_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 7))
#define GPIOI_PCLK_EN()				(RCC -> RCC_AHB1ENR |= (1 << 8))

//Clock Disable MACROS for GPIOx peripherals
#define GPIOA_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 0))
#define GPIOB_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 1))
#define GPIOC_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 2))
#define GPIOD_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 3))
#define GPIOE_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 4))
#define GPIOF_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 5))
#define GPIOG_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 6))
#define GPIOH_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 7))
#define GPIOI_PCLK_DEN()				(RCC -> RCC_AHB1ENR &= ~(1 << 8))

//Clock Enable MACROS for I2Cx peripherals
#define I2C1_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 21))
#define I2C2_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 22))
#define I2C3_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 23))

//Clock Disable MACROS for I2Cx peripherals
#define I2C1_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 21))
#define I2C2_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 22))
#define I2C3_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 23))

//Clock Enable MACROS for USARTx peripherals
#define USART1_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 4))
#define USART2_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 17))
#define USART3_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 18))
#define USART6_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 5))

//Clock Disable MACROS for USARTx peripherals
#define USART1_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 4))
#define USART2_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 17))
#define USART3_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 18))
#define USART6_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 5))

//Clock Enable MACROS for SPIx peripherals
#define SPI1_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 12))
#define SPI2_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 14))
#define SPI3_PCLK_EN()				(RCC -> RCC_APB1ENR |= (1 << 15))
#define SPI4_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 13))
#define SPI5_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 20))
#define SPI6_PCLK_EN()				(RCC -> RCC_APB2ENR |= (1 << 21))

//Clock Disable MACROS for SPIx peripherals
#define SPI1_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 12))
#define SPI2_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 14))
#define SPI3_PCLK_DEN()				(RCC -> RCC_APB1ENR &= ~(1 << 15))
#define SPI4_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 13))
#define SPI5_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 20))
#define SPI6_PCLK_DEN()				(RCC -> RCC_APB2ENR &= ~(1 << 21))

//Clock Enable MACROs for SYSCFG peripherals
#define SYSCFG_PCLK_EN()			(RCC -> RCC_APB2ENR |= (1 << 14))

//Clock Disable MACROs for SYSCFG peripherals
#define SYSCFG_PCLK_DEN()			(RCC -> RCC_APB2ENR &= ~(1 << 14))


//Reseting GPIOx
#define GPIOA_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<0)); (RCC -> RCC_AHB1RSTR &= ~(1<<0)); } while(0)
#define GPIOB_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<1)); (RCC -> RCC_AHB1RSTR &= ~(1<<1)); } while(0)
#define GPIOC_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<2)); (RCC -> RCC_AHB1RSTR &= ~(1<<2)); } while(0)
#define GPIOD_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<3)); (RCC -> RCC_AHB1RSTR &= ~(1<<3)); } while(0)
#define GPIOE_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<4)); (RCC -> RCC_AHB1RSTR &= ~(1<<4)); } while(0)
#define GPIOF_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<5)); (RCC -> RCC_AHB1RSTR &= ~(1<<5)); } while(0)
#define GPIOG_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<6)); (RCC -> RCC_AHB1RSTR &= ~(1<<6)); } while(0)
#define GPIOH_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<7)); (RCC -> RCC_AHB1RSTR &= ~(1<<7)); } while(0)
#define GPIOI_REG_RESET()			do { (RCC -> RCC_AHB1RSTR |= (1<<8)); (RCC -> RCC_AHB1RSTR &= ~(1<<8)); } while(0)

#define GPIO_BASE_ADDR_TO_CODE(x)	( 	(x == GPIOA) ? 0 :\
										(x == GPIOB) ? 1 :\
										(x == GPIOC) ? 2 :\
										(x == GPIOD) ? 3 :\
										(x == GPIOE) ? 4 :\
										(x == GPIOF) ? 5 :\
										(x == GPIOG) ? 6 :\
										(x == GPIOH) ? 7 :\
										(x == GPIOI) ? 8 :0 )

#define IRQ_NO_EXTI0 					6
#define IRQ_NO_EXTI1 					7
#define IRQ_NO_EXTI2 					8
#define IRQ_NO_EXTI3 					9
#define IRQ_NO_EXTI4 					10
#define IRQ_NO_EXTI9_5 					23

#define NVIC_IRQ_PRI0    				0
#define NVIC_IRQ_PRI15    				15

//Generic MACROs
#define ENABLE						1
#define DISABLE						0
#define SET							ENABLE
#define RESET						DISABLE
#define GPIO_PIN_SET				SET
#define GPIO_PIN_RESET				RESET
#define FLAG_ON						SET
#define FLAG_OFF					RESET


#include "stm32f4xx_gpio_header.h"

#endif /* INC_STM32F4XX_H_ */
