#ifndef INC_STM32F4XX_GPIO_DRIVER_H_
#define INC_STM32F4XX_GPIO_DRIVER_H_

#include "stm32f4xx.h"

//Configuration structure for GPIO PIN
typedef struct{
	uint16_t GPIO_PIN_NUMBER;					// PIN 0 - 15
	uint16_t GPIO_PIN_MODE;						// 00: Input (reset state),01: General purpose output mode,10: Alternate function mode,11: Analog mode
	uint16_t GPIO_PIN_SPEED;					// 00:Low, 01:Medium, 10:High, 11:Very High
	uint16_t GPIO_PIN_PUPD;						// 00: No pull-up,01: Pull-up,10: Pull-down,11: Reserved
	uint16_t GPIO_PIN_OTYPE;					// 0: Output push-pull (reset state),1: Output open-drain
	uint16_t GPIO_PIN_ALTERNATE_FUNCTION;		//
}GPIO_PIN_CONFIG_t;


//Handle Structure of GPIO PIN
typedef struct{
	GPIO_RegDef_t *pGPIOx;
	GPIO_PIN_CONFIG_t GPIO_Pin_Config;
}GPIO_Handler_t;


//GPIO Pin numbers
#define GPIO_PIN_NUM_0				0
#define GPIO_PIN_NUM_1				1
#define GPIO_PIN_NUM_2				2
#define GPIO_PIN_NUM_3				3
#define GPIO_PIN_NUM_4				4
#define GPIO_PIN_NUM_5				5
#define GPIO_PIN_NUM_6				6
#define GPIO_PIN_NUM_7				7
#define GPIO_PIN_NUM_8				8
#define GPIO_PIN_NUM_9				9
#define GPIO_PIN_NUM_10				10
#define GPIO_PIN_NUM_11				11
#define GPIO_PIN_NUM_12				12
#define GPIO_PIN_NUM_13				13
#define GPIO_PIN_NUM_14				14
#define GPIO_PIN_NUM_15				15

//GPIO Modes
#define GPIO_MODE_IN				0
#define GPIO_MODE_OUT				1
#define GPIO_MODE_ALT_FUNC			2
#define GPIO_MODE_ANALOG			3
#define GPIO_MODE_INT_FT			4
#define GPIO_MODE_INT_RT			5
#define GPIO_MODE_INT_RFT			6


//GPIO Speed
#define GPIO_SPEED_LOW				0
#define GPIO_SPEED_MEDIUM			1
#define GPIO_SPEED_HIGH				2
#define GPIO_SPEED_VERYHIGH			3

//GPIO Pull Up and Pull Down
#define GPIO_PUPD_NO				0
#define GPIO_PUPD_PULLUP			1
#define GPIO_PUPD_PULLDOWN			2

//GPIO Pin Output Type
#define GPIO_OTYPE_PUSHPULL			0
#define GPIO_OTYPE_OPENDRAIN		1

//User Defined APIs
//Initializing GPIO
void GPIO_Init(GPIO_Handler_t *pGPIOHandler);
void GPIO_DeInit(GPIO_RegDef_t *pGPIOx);

//Enabling and Disabling Clock
void GPIO_Clk_En(GPIO_RegDef_t *pGPIOx, uint8_t EnorDen);

//Read and Write
uint8_t GPIO_Read_From_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber);
void GPIO_Write_To_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber, uint8_t Value);
uint16_t GPIO_Read_From_Port(GPIO_RegDef_t *pGPIOx);
void GPIO_Write_To_Port(GPIO_RegDef_t *pGPIOx, uint16_t Value);
void GPIO_Toggle_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber);

//Interrupt Functions
void GPIO_IRQ_INT_Config(uint8_t IRQ_Number, uint8_t EnorDen);
void GPIO_IRQ_Priority_Config(uint8_t IRQ_Number, uint32_t IRQ_Priority);
void GPIO_IRQ_Handling(uint8_t Pin_Number);

#endif /* INC_STM32F4XX_GPIO_DRIVER_H_ */
