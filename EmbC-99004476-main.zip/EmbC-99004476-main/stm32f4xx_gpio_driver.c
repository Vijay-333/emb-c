#include "stm32f4xx_gpio_header.h"

/*
 * @Brief: Enabling or Disabling the ports
 * @Param1: pGPIOx
 * @Param2: EnorDen
 * @Return: None
 */
void GPIO_Clk_En(GPIO_RegDef_t *pGPIOx, uint8_t EnorDen){
	if(EnorDen == ENABLE){
		if(pGPIOx == GPIOA)
		{
			GPIOA_PCLK_EN();
		}
		else if(pGPIOx == GPIOB)
		{
			GPIOB_PCLK_EN();
		}
		else if(pGPIOx == GPIOC)
		{
			GPIOC_PCLK_EN();
		}
		else if(pGPIOx == GPIOD)
		{
			GPIOD_PCLK_EN();
		}
		else if(pGPIOx == GPIOE)
		{
			GPIOE_PCLK_EN();
		}
		else if(pGPIOx == GPIOF)
		{
			GPIOF_PCLK_EN();
		}
		else if(pGPIOx == GPIOG)
		{
			GPIOG_PCLK_EN();
		}
		else if(pGPIOx == GPIOH)
		{
			GPIOH_PCLK_EN();
		}
		else if(pGPIOx == GPIOI)
		{
			GPIOI_PCLK_EN();
		}
	}
	else
	{
		if(pGPIOx == GPIOA)
		{
			GPIOA_PCLK_DEN();
		}
		else if(pGPIOx == GPIOB)
		{
			GPIOB_PCLK_DEN();
		}
		else if(pGPIOx == GPIOC)
		{
			GPIOC_PCLK_DEN();
		}
		else if(pGPIOx == GPIOD)
		{
			GPIOD_PCLK_DEN();
		}
		else if(pGPIOx == GPIOE)
		{
			GPIOE_PCLK_DEN();
		}
		else if(pGPIOx == GPIOF)
		{
			GPIOF_PCLK_DEN();
		}
		else if(pGPIOx == GPIOG)
		{
			GPIOG_PCLK_DEN();
		}
		else if(pGPIOx == GPIOH)
		{
			GPIOH_PCLK_DEN();
		}
		else if(pGPIOx == GPIOI)
		{
			GPIOI_PCLK_DEN();
		}
	}
}

/*
 * @Brief: Configuring Pin Mode, Speed, Pull up or Pull Down, Output Type, Alternate Functions
 * @Param1: GPIO Handler
 * @Return: None
 */

void GPIO_Init(GPIO_Handler_t *pGPIOHandler){

	uint32_t temp = 0;

	//Configuring Mode
	if(pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE <= GPIO_MODE_ANALOG){
		temp = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
		pGPIOHandler->pGPIOx->MODER &= ~(0x3 << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER));
		pGPIOHandler->pGPIOx->MODER |= temp;
		temp = 0;
	}
	else{
		if(pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE == GPIO_MODE_INT_FT){
			EXTI->EXTI_FTSR |= (1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
			EXTI->EXTI_RTSR &= ~(1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
		}
		else if(pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE == GPIO_MODE_INT_RT){
			EXTI->EXTI_FTSR &= ~(1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
			EXTI->EXTI_RTSR |= (1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
		}
		else if(pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE == GPIO_MODE_INT_RFT){
			EXTI->EXTI_FTSR |= (1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
			EXTI->EXTI_RTSR |= (1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
		}

		//Configuring GPIO port in SYSCFG
		uint8_t temp1 = 0;
		uint8_t temp2 = 0;
		uint8_t portcode = 0;

		temp1 = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER / 4;
		temp2 = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER % 4;
		portcode = GPIO_BASE_ADDR_TO_CODE(pGPIOHandler->pGPIOx);
		SYSCFG_PCLK_EN();
		SYSCFG->SYSCFG_EXTICR[temp1] = portcode << (4 * temp2);

		//Enabling EXTI Interrupt delivery using IMR
		EXTI->EXTI_IMR |= 1 << pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER;
	}
	//Configuring Speed
	temp = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_SPEED << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
	pGPIOHandler->pGPIOx->OSPEEDR &= ~(0x3 << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER));
	pGPIOHandler->pGPIOx->OSPEEDR |= temp;
	temp = 0;

	//Configuring Output Type
	temp = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_OTYPE << (pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
	pGPIOHandler->pGPIOx->OTYPER &= ~(1 << (pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER));
	pGPIOHandler->pGPIOx->OTYPER |= temp;
	temp = 0;

	//Configuring Pull Up and Pull Down
	temp = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_PUPD << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER);
	pGPIOHandler->pGPIOx->PUPDR &= ~(0x3 << (2 * pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER));
	pGPIOHandler->pGPIOx->PUPDR |= temp;
	temp = 0;

	//Configuring Alternate Functions
	if(pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_MODE == GPIO_MODE_ALT_FUNC)
	{
		uint8_t temp1 = 0;
		uint8_t temp2 = 0;

		temp1 = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER / 8;
		temp2 = pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_NUMBER % 8;

		pGPIOHandler->pGPIOx->AFR[temp1] &= ~(0xF << (4 * temp2));
		pGPIOHandler->pGPIOx->AFR[temp1] |= pGPIOHandler->GPIO_Pin_Config.GPIO_PIN_ALTERNATE_FUNCTION << (4 * temp2);
	}

}

/*
 *@Brief: Resetting the GPIO pins
 *@Param1: pGPIOx
 *@Return: None
 */

void GPIO_DeInit(GPIO_RegDef_t *pGPIOx){
	if(pGPIOx == GPIOA)
	{
		GPIOA_REG_RESET();
	}
	else if(pGPIOx == GPIOB)
	{
		GPIOB_REG_RESET();
	}
	else if(pGPIOx == GPIOC)
	{
		GPIOC_REG_RESET();
	}
	else if(pGPIOx == GPIOD)
	{
		GPIOD_REG_RESET();
	}
	else if(pGPIOx == GPIOE)
	{
		GPIOE_REG_RESET();
	}
	else if(pGPIOx == GPIOF)
	{
		GPIOF_REG_RESET();
	}
	else if(pGPIOx == GPIOG)
	{
		GPIOG_REG_RESET();
	}
	else if(pGPIOx == GPIOH)
	{
		GPIOH_REG_RESET();
	}
	else if(pGPIOx == GPIOI)
	{
		GPIOI_REG_RESET();
	}
}

/*
 * @Brief: Reading input using GPIO pin
 * @Param1: pGPIOx
 * @Param2: PinNumber
 * @Return: uint8_t
 */

uint8_t GPIO_Read_From_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber){
	uint8_t value = 0;
	value = (uint8_t)((pGPIOx->IDR >> PinNumber) & 0x00000001) ;
	return value;
}

/*
 *@Brief: Writing into GPIO pin
 *@Param1: pGPIOx
 *@Param2: PinNumber
 *@Param3: Value
 *@Return: None
 */

void GPIO_Write_To_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber, uint8_t Value){
	if(Value == GPIO_PIN_SET)
	{
		pGPIOx->BSRR |= (1 << PinNumber);
	}
	else
	{
		pGPIOx->BSRR &= ~(1 << PinNumber);
	}
}

/*
 * @Brief: Reading input using GPIO port
 * @Param1: pGPIOx
 * @Return: uint16_t
 */

uint16_t GPIO_Read_From_Port(GPIO_RegDef_t *pGPIOx){
	uint16_t value_port = 0;
	value_port = (uint16_t)(pGPIOx->IDR);
	return value_port;
}

/*
 *@Brief: Writing into GPIO port
 *@Param1: pGPIOx
 *@Param2: Value
 *@Return: None
 */

void GPIO_Write_To_Port(GPIO_RegDef_t *pGPIOx, uint16_t Value){
	pGPIOx->ODR = Value;
}

/*
 *@Brief:
 *@Param1: pGPIOx
 *@Param2: PinNumber
 *@Return: None
 */

void GPIO_Toggle_Pin(GPIO_RegDef_t *pGPIOx, uint8_t PinNumber){
	pGPIOx->ODR ^= (1 << PinNumber);
}


void GPIO_IRQ_INT_Config(uint8_t IRQ_Number, uint8_t EnorDen){
	if(EnorDen == ENABLE){
		if(IRQ_Number <= 31){
			*NVIC_ISER0 |= (1 << IRQ_Number);
		}
		else if (IRQ_Number > 31 && IRQ_Number < 64){
			*NVIC_ISER1 |= (1 << (IRQ_Number % 32));
		}
		else if (IRQ_Number >= 64 && IRQ_Number < 96){
			*NVIC_ISER2 |= (1 << (IRQ_Number % 64));
		}
	}
	else{
		if(IRQ_Number <= 31){
			*NVIC_ICER0 |= (1 << IRQ_Number);
		}
		else if (IRQ_Number > 31 && IRQ_Number < 64){
			*NVIC_ICER1 |= (1 << (IRQ_Number % 32));
		}
		else if (IRQ_Number >= 64 && IRQ_Number < 96){
			*NVIC_ICER2 |= (1 << (IRQ_Number % 64));
		}
	}
}
void GPIO_IRQ_Priority_Config(uint8_t IRQ_Number, uint32_t IRQ_Priority){
	uint8_t iprx = IRQ_Number / 4;
	uint8_t iprx_section = IRQ_Number % 4;
	uint8_t shift_count = (8 * iprx_section) + (8 - NO_PR_BITS_IMPLEMENTED);

	*(NVIC_IPR0 + iprx) |= (IRQ_Priority << shift_count);
}
void GPIO_IRQ_Handling(uint8_t Pin_Number){
	if(EXTI->EXTI_PR & (1 << Pin_Number)){
		EXTI->EXTI_PR |= (1 << Pin_Number);
	}
}


void GPIO_Alternate_Func_Config(void);

