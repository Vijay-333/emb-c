/**
 * @file stm32f4xx.h
 * @author Vijay Vel Raja T
 * @brief LED operations of STM32f4xx using User Push Button
 * @version 0.1
 * @date 2021-07-10
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include "stm32f4xx.h"

volatile int count = 0;


int init_state(void)
{
    //Initial Condition

    for(uint32_t i = 0; i < 16; i++)
    {
        for (uint32_t j = 0; j < 40000000; j++);
        GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NUMBER_12);
        GPIO_ToggleOutputPin(GPIOD, GPIO_PIN_NUMBER_15);
    }

    return 0;
}

int main(void)
{
    GPIO_HANDLE_t GPIO_LED1;
    GPIO_HANDLE_t GPIO_LED2;
    GPIO_HANDLE_t GPIO_LED3;
    GPIO_HANDLE_t GPIO_LED4;
    GPIO_HANDLE_t GPIO_PUSH_BUTTON;

    //Initialising LEDs and Push button

    GPIO_LED1.pGPIOx = GPIOD;
    GPIO_LED1.GPIO_PIN_CONFIG.GPIO_PIN_NUMBER = GPIO_PIN_NUMBER_12;
    GPIO_LED1.GPIO_PIN_CONFIG.GPIO_MODE = GPIO_MODE_OUT;
    GPIO_LED1.GPIO_PIN_CONFIG.GPIO_PIN_SPEED = GPIO_SPEED_VHIGH;
    GPIO_LED1.GPIO_PIN_CONFIG.GPIO_PIN_OPTYPE = GPIO_OP_TYP_PP;
    GPIO_LED1.GPIO_PIN_CONFIG.GPIO_PIN_PUPDR = GPIO_NO_PUPD;

    GPIO_LED2.pGPIOx = GPIOD;
    GPIO_LED2.GPIO_PIN_CONFIG.GPIO_PIN_NUMBER = GPIO_PIN_NUMBER_13;
    GPIO_LED2.GPIO_PIN_CONFIG.GPIO_MODE = GPIO_MODE_OUT;
    GPIO_LED2.GPIO_PIN_CONFIG.GPIO_PIN_SPEED = GPIO_SPEED_VHIGH;
    GPIO_LED2.GPIO_PIN_CONFIG.GPIO_PIN_OPTYPE = GPIO_OP_TYP_PP;
    GPIO_LED2.GPIO_PIN_CONFIG.GPIO_PIN_PUPDR = GPIO_NO_PUPD;

    
    GPIO_LED3.pGPIOx = GPIOD;
    GPIO_LED3.GPIO_PIN_CONFIG.GPIO_PIN_NUMBER = GPIO_PIN_NUMBER_14;
    GPIO_LED3.GPIO_PIN_CONFIG.GPIO_MODE = GPIO_MODE_OUT;
    GPIO_LED3.GPIO_PIN_CONFIG.GPIO_PIN_SPEED = GPIO_SPEED_VHIGH;
    GPIO_LED3.GPIO_PIN_CONFIG.GPIO_PIN_OPTYPE = GPIO_OP_TYP_PP;
    GPIO_LED3.GPIO_PIN_CONFIG.GPIO_PIN_PUPDR = GPIO_NO_PUPD;

    GPIO_LED4.pGPIOx = GPIOD;
    GPIO_LED4.GPIO_PIN_CONFIG.GPIO_PIN_NUMBER = GPIO_PIN_NUMBER_15;
    GPIO_LED4.GPIO_PIN_CONFIG.GPIO_MODE = GPIO_MODE_OUT;
    GPIO_LED4.GPIO_PIN_CONFIG.GPIO_PIN_SPEED = GPIO_SPEED_VHIGH;
    GPIO_LED4.GPIO_PIN_CONFIG.GPIO_PIN_OPTYPE = GPIO_OP_TYP_PP;
    GPIO_LED4.GPIO_PIN_CONFIG.GPIO_PIN_PUPDR = GPIO_NO_PUPD;

    GPIO_PUSH_BUTTON.pGPIOx = GPIOA;
    GPIO_PUSH_BUTTON.GPIO_PIN_CONFIG.GPIO_PIN_NUMBER = GPIO_PIN_NUMBER_0;
    GPIO_PUSH_BUTTON.GPIO_PIN_CONFIG.GPIO_MODE = GPIO_MODE_IT_FT;
    GPIO_PUSH_BUTTON.GPIO_PIN_CONFIG.GPIO_PIN_SPEED = GPIO_SPEED_VHIGH;
    GPIO_PUSH_BUTTON.GPIO_PIN_CONFIG.GPIO_PIN_PUPDR = GPIO_PU;

    GPIO_PeriClockControl(GPIOD, ENABLE);
    GPIO_PeriClockControl(GPIOA, ENABLE);
    
    GPIO_Init(&GPIO_LED1);
    GPIO_Init(&GPIO_LED2);
    GPIO_Init(&GPIO_LED3);
    GPIO_Init(&GPIO_LED4);
    GPIO_Init(&GPIO_PUSH_BUTTON);


    GPIO_IRQPriorityConfig(IRQ_NO_EXTI0,NVIC_IRQ_PRI0);
    GPIO_IRQInterruptConfig(IRQ_NO_EXTI0,ENABLE);

    init_state();

    while(1)
	{
        //After 5 seconds
        if(count == 1)
        {
            for(uint32_t i = 0; i < 16; i++)
            {
                for (uint32_t j = 0; j < 40000000; j++);
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_12, SET);
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_13, SET); 
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_14, RESET);
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_15, RESET); 
            }
            while(1)
            {
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_12, RESET);
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_13, RESET); 
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_14, SET);
                GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_15, SET);
            }
            count = 0;
        }

        if (count == 2)
        {
            GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_12, SET);
            GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_13, RESET); 
            GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_14, RESET);
            GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_15, SET);
            count = 0;
        }
        GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_13, SET);
        GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NUMBER_14, SET);
    }
        
	return 0;
}

void EXTI0_IRQHandler(void)
{
    count++;
    GPIO_IRQHandling(GPIO_PIN_NUMBER_0);
}