Status: Completed expect User button pressed twice.
